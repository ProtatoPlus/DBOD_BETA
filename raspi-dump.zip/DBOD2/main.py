import cherrypy


class application:
    @cherrypy.expose
    def index(self):
        return """<html>
          <head></head>
          <body>
            <p>Make bot<br>
            <form method="get" action="square">
              <input type="text" name="num" placeholder="token"/>
              <button type="submit">create</button>
            </form>
            </p>
          </body>
        </html>"""

    @cherrypy.expose
    def square(self, num=2):
        return "Bot is being created."

if __name__ == '__main__':
   cherrypy.config.update({'server.socket_host': '192.168.10.66'})
   cherrypy.quickstart(application(), '/')
